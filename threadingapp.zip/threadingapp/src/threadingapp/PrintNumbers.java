
package threadingapp;

public class PrintNumbers {
    public void print(){
        for(int i=0; i<10; i++){
            System.out.println(Thread.currentThread().getName()+" : "+i);
        }
}}
class ThreadDemo1 extends Thread
{
    String name;
    PrintNumbers pn;
    
    public ThreadDemo1(String name, PrintNumbers pn)
    {
        super(name);
        this.name = name;
        this.pn = pn;
    }
    public void run(){
        try{
            synchronized(pn){
                pn.print();
            }
            Thread.sleep(250);
        }catch(InterruptedException exp){
            exp.printStackTrace();
                    
                    }
        }
    }
  class ThreadDemo2 extends Thread
{
    String name;
    PrintNumbers pn;
    
    public ThreadDemo2(String name, PrintNumbers pn)
    {
        super(name);
        this.name = name;
        this.pn = pn;
    }
    public void run(){
        try{
            synchronized(pn){
                pn.print();
            }
            Thread.sleep(250);
        }catch(InterruptedException exp){
            exp.printStackTrace();
                    
                    }
        }
    }          
