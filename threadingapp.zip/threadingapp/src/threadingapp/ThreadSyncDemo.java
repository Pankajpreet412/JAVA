
package threadingapp;

public class ThreadSyncDemo {
    public static void main(String[] args) {
        PrintNumbers pn = new PrintNumbers();
        ThreadDemo1 t1 = new ThreadDemo1("MY",pn);
        ThreadDemo2 t2 = new ThreadDemo2("YOUR",pn);
        
        t1.start();
        t2.start();
    }
    
}
